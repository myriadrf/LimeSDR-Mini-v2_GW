#ifndef MICO32_GPIOSERVICE_HEADER_FILE
#define MICO32_GPIOSERVICE_HEADER_FILE


#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */



#ifdef __cplusplus
};
#endif /* __cplusplus */


#endif /* MICO32_GPIOSERVICE_HEADER_FILE */
