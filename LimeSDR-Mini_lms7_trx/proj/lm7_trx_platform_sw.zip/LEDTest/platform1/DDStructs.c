#include "DDStructs.h"


/* lm32_top instance LM32*/
struct st_LatticeMico32Ctx_t lm32_top_LM32 = {
    "LM32"};


/* gpio instance LED*/
struct st_MicoGPIOCtx_t gpio_LED = {
    "LED",
    0x80000000,
    255,
    1,
    0,
    0,
    0,
    8,
    1,
    1,
    0,
    32,
};


/* gpio instance GPIO*/
struct st_MicoGPIOCtx_t gpio_GPIO = {
    "GPIO",
    0x80000100,
    255,
    0,
    0,
    1,
    0,
    1,
    1,
    1,
    0,
    32,
};


/* Reg_Comp instance GPO*/
struct st_reg_device Reg_Comp_GPO = {
    305441741,
    0x80000200};


/* spi instance spi*/
struct st_MicoSPICtx_t spi_spi = {
    "spi",
    0x80000300,
    1,
    1,
    2,
    32,
    0,
};


/* FIFO_Comp instance FIFO*/
struct st_fifo_device FIFO_Comp_FIFO = {
    305441741,
    0x80000400,
};


/* uart_core instance uart*/
  /* array declaration for rxBuffer */
   unsigned char _uart_core_uart_rxBuffer[4];
  /* array declaration for txBuffer */
   unsigned char _uart_core_uart_txBuffer[4];
struct st_MicoUartCtx_t uart_core_uart = {
    "uart",
    0x80000500,
    3,
    1,
    115200,
    8,
    1,
    4,
    4,
    1,
    1,
    0,
    _uart_core_uart_rxBuffer,
    _uart_core_uart_txBuffer,
};

