/**************************************************************
 * This example exercises LEDs on LatticeMico32 Development   *
 * board.                                                     *
 *                                                            *
 *                                                            *
 *                                                            *
 *------------------------------------------------------------*
 * PREREQUISITES:                                             *
 *                                                            *                                                                                                    
 * - GPIO with 8-bit output named LED connected to the        *
 *   board's LED pins.                                        *
 **************************************************************/
#include "DDStructs.h"
#include "LookupServices.h"
#include "stdint.h"
//#include <stdio.h>
#include "MicoUtils.h"
#include "system_conf.h"
#include "MicoGPIO.h"
#include "MicoSPIService.h"

#include "LMS64C_protocol.h"

#define sbi(p,n) ((p) |= (1UL << (n)))
#define cbi(p,n) ((p) &= ~(1 << (n)))

#define SPI_FPGA_SELECT 0x01
#define SPI_LMS7002_SELECT 0x02

const char *LED_GPIO_INSTANCE = "LED";
const char *GPIO_GPIO_INSTANCE = "GPIO";
const char *SPI_INSTANCE = "spi";
const unsigned int uiBlink = 1;

uint8_t test, block, cmd_errors, glEp0Buffer_Rx[64], glEp0Buffer_Tx[64];
tLMS_Ctrl_Packet *LMS_Ctrl_Packet_Tx = (tLMS_Ctrl_Packet*)glEp0Buffer_Tx;
tLMS_Ctrl_Packet *LMS_Ctrl_Packet_Rx = (tLMS_Ctrl_Packet*)glEp0Buffer_Rx;


unsigned int lat_wishbone_spi_command(MicoSPICtx_t *pMaster, int slave_address, unsigned int write_data, uint8_t *rd_data)
{
	//SPI
	unsigned int read_data = 0x0;
	unsigned int slave_address_int;
	uint32_t* dest = (uint32_t*)rd_data;
	/* Enable slave by writing to master */
	MicoSPISetSlaveEnable(pMaster, slave_address);
	/* Check slave enable status. */
	MicoSPIGetSlaveEnable(pMaster, &slave_address_int);
	if(slave_address != slave_address_int){
		//printf("failed to select internal slave! fatal error\n");
		while(1);
	}

	/* write data targetted for slave */
	MicoSPITxData(pMaster, write_data,1);

	/* wait for master's transmission to complete */
	while(1){
		volatile unsigned int iTimeout;
		unsigned int iValue;
		volatile unsigned int *pStatus;
		do{
			if(MicoSPIIsTxDone(pMaster)!=0)
				break;
		}while(1);

		/* read data if there's data to read */
		iTimeout = 0;
		do{
			if(MicoSPIRxData(pMaster, &read_data, 0) == 0)
				break;
			if(iTimeout >= 10){
				pStatus = (volatile unsigned int *)(pMaster->base + 8);
				iValue = *pStatus;
				pStatus = (volatile unsigned int *)(pMaster->base + 0);
				iValue = *pStatus;
				//printf("master failed to rx data within a second %d\n", iTimeout);
				while(1);
			}
			iTimeout++;
			MicoSleepMilliSecs(100);
		}while(1);
		break;
	}
	*dest = read_data;
	return read_data;

}

unsigned int IORD(uint32_t BASE, uint32_t OFFSET)
{
	uint32_t *word_aligned_address = (uint32_t*) (BASE + OFFSET * 4);
	uint32_t val = 0;

	val = *word_aligned_address;
	return val;
}

void IOWR(unsigned int BASE, unsigned int OFFSET, unsigned int DATA)
{
	unsigned int *reg = BASE + OFFSET * 4;
	*reg = DATA;
}

int FIFO_loopback_test(int base_addr)
{
    unsigned int fifo_val =0;
    int fifo_wrcnt = 0;
    int fifo_wr_data =0;
    int fifo_rd_cnt =0;
    int fifo_wr_data_array[4];
    int fifo_rd_data_array[4];

	//FIFO testing
	fifo_wrcnt = 0;
	fifo_wr_data = 1;

	//Reset FIFO
	//printf("FIFO reset \n\n");
	IOWR(base_addr, 3, 0x1);
	IOWR(base_addr, 3, 0x0);
	MicoSleepMilliSecs(100);

	while ((IORD(base_addr, 2) & 0x2) != 0x2)
	{
		IOWR(base_addr, 0, fifo_wr_data);
		//printf("FIFO Write: %#x \n", fifo_wr_data);
		fifo_wr_data_array[fifo_wrcnt]=fifo_wr_data;
		fifo_wrcnt++;
		fifo_wr_data++;
		//MicoSleepMilliSecs(100);

	}
	//printf("FIFO Write counter: %d \n", fifo_wrcnt);

	fifo_rd_cnt=0;
	while (!(IORD(base_addr, 2) & 0x1))
	{
		fifo_val = IORD(base_addr, 1);
		fifo_rd_data_array[fifo_rd_cnt] = fifo_val;
		//MicoSleepMilliSecs(100);
		//printf("FIFO Read: %#x \n", fifo_val);
		fifo_rd_cnt++;
	}
	//printf("FIFO Read counter: %d \n", fifo_rd_cnt);

	int i = 0;
	if (fifo_wrcnt == fifo_rd_cnt){
		//printf("FIFO WR/RD counters match \n");
		for (i =0; i < fifo_wrcnt; i++){
			if (fifo_wr_data_array[i] != fifo_rd_data_array[i]){
				//printf("FIFO WR/RD arrays does not match \n");
				return(0);
			}
		}
	}
	else {
		//printf("FIFO WR/RD counters does not match \n");
		return(0);
	}

	return(1);
}

/**
 * Gets 64 bytes packet from FIFO.
 */

void getFifoData(uint8_t *buf, uint8_t k)
{
	uint8_t cnt = 0;
	uint32_t* dest = (uint32_t*)buf;
	for(cnt=0; cnt<k/sizeof(uint32_t); ++cnt)
	{
		dest[cnt] = IORD(FIFO_BASE_ADDRESS, 1);	// Read Data from FIFO
	};
}

/**	This function checks if all blocks could fit in data field.
*	If blocks will not fit, function returns TRUE. */
unsigned char Check_many_blocks (unsigned char block_size)
{
	if (LMS_Ctrl_Packet_Rx->Header.Data_blocks > (sizeof(LMS_Ctrl_Packet_Tx->Data_field)/block_size))
	{
		LMS_Ctrl_Packet_Tx->Header.Status = STATUS_BLOCKS_ERROR_CMD;
		return 1;
	}
	else return 0;
	return 1;
}



int main(void)
{
    uint32_t* dest = (uint32_t*)glEp0Buffer_Tx;
    volatile int spirez;
    uint16_t * ptr_spi_wrdata;
    uint32_t * p_spi_wrdata32;
    char cnt = 0;

	unsigned char iValue = 0x1;
	unsigned int gpio_val = 0x0;
	unsigned int gpo_val = 0x0;
	unsigned int gpio_rd_val = 0x0;
	unsigned int gpio_rd_val2 = 0x0;
	static unsigned int spi_read_val = 0x0;
	unsigned int spi_read_val_p = 0x0;
	unsigned char iShiftLeft = 1;

	/*
	* Names of the SPI master and slave, as
	* defined in MSB
	*/
	const char *const SPIM_INSTANCE_NAME = "spim_";

    /* Fetch GPIO instance named "LED" */
	MicoGPIOCtx_t *leds = (MicoGPIOCtx_t *)MicoGetDevice(LED_GPIO_INSTANCE);
    if (leds == 0) {
        //printf("failed to find GPIO instance named LED\r\n");
        return(0);
    }
    //printf("Found GPIO instance named LED\r\n");

    /* Fetch GPIO instance named "GPIO" */
	MicoGPIOCtx_t *gpio = (MicoGPIOCtx_t *)MicoGetDevice(GPIO_GPIO_INSTANCE);
    if (gpio == 0) {
        //printf("failed to find GPIO instance named GPIO\r\n");
        return(0);
    }
    //printf("Found GPIO instance named GPIO\r\n");

    unsigned int *reg = GPIO_BASE_ADDRESS;
    unsigned int *gpo_reg = GPO_BASE_ADDRESS;
    unsigned int *gpo_reg_04 = GPO_BASE_ADDRESS + 4;
    unsigned int *gpo_reg_08 = GPO_BASE_ADDRESS + 8;

	
    /* if we're not to blink, return immediately */
    if (uiBlink == 0)
        return(0);
    MICO_GPIO_WRITE_DATA(gpio,0xFFFFFFFF);

    *((volatile unsigned char *)(leds->base)) = 0xFF;



    //SPI test
    int runs = 0;
    int slave_address = 0x01;
    int master_txdata = 0x0;
    MicoSPICtx_t *pMaster;
    /* Fetch pointers to master/slave SPI dev-ctx instances */
    pMaster = (MicoSPICtx_t *)MicoGetDevice(SPI_INSTANCE);
    //TODO: Remove after testing
    int spi_rdwr = 0;
    unsigned int spi_wrval = 0;

    /* Make sure pointers are valid */
    if(pMaster == 0){
    	//printf("Cannot use SPI Master as ctx is unidentified\n");
    return(0);
    }

    // RESET FIFO once on power-up
	IOWR(FIFO_BASE_ADDRESS, 3, 0x1);
	IOWR(FIFO_BASE_ADDRESS, 3, 0x0);


	while(1) {
		//TODO: REMOVE after testing
		/*FIFO is connected in loopback, first we write LMS64C command to FIFO then read and execute */
		spirez = IORD(FIFO_BASE_ADDRESS, 2);
		spi_rdwr = ~spi_rdwr;

		/*
		if (spi_rdwr==0) {
		// SPI Bulk read
			IOWR(FIFO_BASE_ADDRESS, 0, 0x56000500); //0
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //1
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000001); //2
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00020003); //3
			IOWR(FIFO_BASE_ADDRESS, 0, 0x000F0000); //4
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //5
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //6
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //7
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //8
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //9
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //10
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //11
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //12
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //13
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //14
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //15
		}

		if (spi_rdwr!=0) {
		//SPI write
			IOWR(FIFO_BASE_ADDRESS, 0, 0x55000100); //0
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //1
			IOWR(FIFO_BASE_ADDRESS, 0, (0x000F0000 | spi_wrval)); //2
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //3
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //4
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //5
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //6
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //7
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //8
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //9
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //10
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //11
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //12
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //13
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //14
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //15
		}
*/


		if (spi_rdwr==0) {
		// LMS SPI bulk read
			IOWR(FIFO_BASE_ADDRESS, 0, 0x22000500); //0
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //1
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000001); //2
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00020003); //3
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00240000); //4
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //5
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //6
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //7
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //8
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //9
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //10
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //11
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //12
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //13
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //14
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //15
		}

		if (spi_rdwr!=0) {
		//LMS SPI write
			IOWR(FIFO_BASE_ADDRESS, 0, 0x21000100); //0
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //1
			IOWR(FIFO_BASE_ADDRESS, 0, (0x00240000 | spi_wrval)); //2
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //3
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //4
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //5
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //6
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //7
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //8
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //9
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //10
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //11
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //12
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //13
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //14
			IOWR(FIFO_BASE_ADDRESS, 0, 0x00000000); //15
		}

		spi_wrval = (spi_wrval + 1) & 0x0000FFFF;



		spirez = IORD(FIFO_BASE_ADDRESS, 2);	// Read FIFO Status

		if(!(spirez & 0x01))
		{
			//Read packet from the FIFO
			getFifoData(glEp0Buffer_Rx, 64);

			memset(glEp0Buffer_Tx, 0, sizeof(glEp0Buffer_Tx)); //fill whole tx buffer with zeros
			cmd_errors = 0;

			LMS_Ctrl_Packet_Tx->Header.Command = LMS_Ctrl_Packet_Rx->Header.Command;
			LMS_Ctrl_Packet_Tx->Header.Data_blocks = LMS_Ctrl_Packet_Rx->Header.Data_blocks;
			LMS_Ctrl_Packet_Tx->Header.Periph_ID = LMS_Ctrl_Packet_Rx->Header.Periph_ID;
			LMS_Ctrl_Packet_Tx->Header.Status = STATUS_BUSY_CMD;

			switch (LMS_Ctrl_Packet_Rx->Header.Command) {

			case CMD_LMS7002_WR:
				if (Check_many_blocks(4))
					break;

				for (block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++) {
					//write reg addr
					sbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 7); //set write bit
					//spirez = alt_avalon_spi_command(FPGA_SPI_BASE, SPI_NR_LMS7002M, 4, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 0, NULL, 0);
					p_spi_wrdata32 = (uint32_t*) &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)];
					spi_read_val = lat_wishbone_spi_command(pMaster, SPI_LMS7002_SELECT, *p_spi_wrdata32, 0);
				}

				LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
				break;

			case CMD_LMS7002_RD:
				if (Check_many_blocks(4))
					break;

				for (block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++) {

					//write reg addr
					cbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 7); //clear write bit
					//spirez = alt_avalon_spi_command(FPGA_SPI_BASE, SPI_NR_LMS7002M, 2, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 2, &LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)], 0);
					ptr_spi_wrdata = (uint16_t*) &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)];
					spi_read_val = lat_wishbone_spi_command(pMaster, SPI_LMS7002_SELECT, ((uint32_t) *ptr_spi_wrdata) << 16, &LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)]);
				}

				LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
				break;

			case CMD_BRDSPI16_WR:
				if(Check_many_blocks (4)) break;

				for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
				{
					sbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 7); //set write bit
					//TODO: spirez = alt_avalon_spi_command(FPGA_SPI_BASE, SPI_NR_FPGA, 4, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)], 0, NULL, 0);
					p_spi_wrdata32 = (uint32_t*) &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 4)];
					spi_read_val = lat_wishbone_spi_command(pMaster, SPI_FPGA_SELECT, *p_spi_wrdata32, 0);
				}

				LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
				break;

			case CMD_BRDSPI16_RD:
				if(Check_many_blocks (4)) break;

				for(block = 0; block < LMS_Ctrl_Packet_Rx->Header.Data_blocks; block++)
				{
					cbi(LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 7);  //clear write bit
					//TODO: spirez = alt_avalon_spi_command(FPGA_SPI_BASE, SPI_NR_FPGA, 2, &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)], 2, &LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)], 0);
					ptr_spi_wrdata = (uint16_t*) &LMS_Ctrl_Packet_Rx->Data_field[0 + (block * 2)];
					spi_read_val = lat_wishbone_spi_command(pMaster, SPI_FPGA_SELECT, ((uint32_t) *ptr_spi_wrdata) << 16, &LMS_Ctrl_Packet_Tx->Data_field[2 + (block * 4)]);
				}

				LMS_Ctrl_Packet_Tx->Header.Status = STATUS_COMPLETED_CMD;
				break;

			default:
				/* This is unknown request. */
				LMS_Ctrl_Packet_Tx->Header.Status = STATUS_UNKNOWN_CMD;
				break;
			}

			//Send response to the command
			for(cnt=0; cnt<64/sizeof(uint32_t); ++cnt)
			{
				IOWR(FIFO_BASE_ADDRESS, 0, dest[cnt]);
			};
		}

		//TODO: REMOVE
		IOWR(FIFO_BASE_ADDRESS, 3, 0x1);
		IOWR(FIFO_BASE_ADDRESS, 3, 0x0);


		//FIFO testing
		/*
		int fifo_status = 0;
		fifo_status = FIFO_loopback_test(FIFO_BASE_ADDRESS);
		*/

		/*
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00000000); // BOARD ID 	@ 0x0000 = 0x0011
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00010000); // MAJOR REV 	@ 0x0002 = 0x0001
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00020000); // COMPILE_REV @ 0x0003 = 0x001F
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x000F0000); // SYNC_SIZE 	@ 0x000F = 0x03FC

		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00040000);
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x8004FFFF);
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00040000);

		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00050000);
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x8005AAAA);
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00050000);

		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00060000);
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x80065555);
		spi_read_val = lat_wishbone_spi_command(pMaster, slave_address, 0x00060000);
		*/

		gpo_val = ~gpo_val;
		//*((volatile unsigned char *)(leds->base)) = ~iValue;
		//*((volatile unsigned char *)(gpio->base)) = gpio_val;
		//MICO_GPIO_WRITE_DATA(gpio,gpio_val);
		//MICO_GPIO_READ_DATA(gpio,gpio_rd_val);
		//gpio_rd_val2 = *reg;
		*gpo_reg = gpo_val;
		unsigned int gpo_reg_04_val = *gpo_reg_04;
		unsigned int gpo_reg_08_val = *gpo_reg_08;

		if (iShiftLeft == 1){
			if (iValue == 0x8) {
				iShiftLeft = 0;
				iValue = 0x4;
			} else {
				iValue = iValue << 1;
			}
		} else {
			iValue = iValue >> 1;
			if (iValue == 0) {
				iValue = 0x02;
				iShiftLeft = 1;
			}
		}
	}
	
    /* all done */
	return(0);
}

